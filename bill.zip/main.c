/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<conio.h>
#include<math.h>

int main(void)
{
    char name[30];
    int units;
    
    const int mincharge=100;
    const double unit1=0.8;
    const double unit2=0.9;
    const double unit3=1.0;
    const double surcharge=0.15;
    double bill=0.0;
    
    printf("\n enter the name of the customer:" );
    scanf("%s", name);
    printf("\n enter the number of units consumed: ");
    scanf("%d", &units);
    
    bill+=mincharge;
    
    if(units<=200)
    {
        bill+=units*unit1;
    }
    else if(units>200 && units<=300)
    {
        bill+=(200*unit1)+((units-200)*unit2);
    }
    else
    {
        bill+=(200*unit1)+(100*unit2)+((units-300)*unit3);
    }  
    if(bill>400)
    {
        bill+=bill*surcharge;
    }
    printf("\n electricity bill\n=====================");
    printf("\n customer name\t:%s", name);
    printf("\n bill amount \t :%0.2lf rupees\n\n", bill);
    return(0);
    
    
}

