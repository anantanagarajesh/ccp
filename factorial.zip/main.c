/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<conio.h>
int factorial(int n);
void main()
{
    int fact,num;
    printf("enter no.:");
    scanf("%d",&num);
    if(num>0)
    {fact=factorial(num);
    printf("\n factorial of %d=%d",num,fact);
    }
    else
    if(num==0)
    printf("\n 1 is factorial of %d", num);
    else
    printf("\n error is that %d is negative", num);
    getch();
}
int factorial(int n)
{
    int result;
    if(n==1)
    return(1);
    else
    result=n*factorial(n-1);
    return(result);
}